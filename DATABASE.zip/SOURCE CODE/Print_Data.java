package criminall;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

class Print_Data implements ActionListener{
    JFrame f;
    JLabel id8,id,aid,id1,aid1,id2,aid2,id3,aid3,id4,aid4,id5,aid5,id6,aid6,id7,id9,aid7,id18,aid9,id10,id11,id12,id13,id14,id15,id16,id17,lab;
    String Crm_Id,name,age,height,weight,city,country,gender,bdate,details;
    JButton b1,b2;
    ImageIcon icon;

    Print_Data(String c_id){
        try{
            conn con = new conn();
            String str = "select * from criminal where Crm_Id = '"+c_id+"'";
            ResultSet rs= con.s.executeQuery(str);

            while(rs.next()){

               
                Crm_Id= rs.getString("Crm_Id");
                name = rs.getString("Name");
                age = rs.getString("Age");
                height = rs.getString("Height");
                weight = rs.getString("Weight");
                city = rs.getString("City");
                country = rs.getString("Country");
                gender = rs.getString("Gender");
                bdate = rs.getString("Birth_date");
                details = rs.getString("Details");
                
            }
        }catch(Exception e){
            e.printStackTrace();
        }
 
        f=new JFrame("Print Data");
        f.setVisible(true);
        f.setSize(900,642);
        f.setLocation(450,200);
        f.setBackground(Color.black);
        f.setLayout(null);


        id9=new JLabel();
        id9.setBounds(0,0,900,700);
        id9.setLayout(null);
        ImageIcon img=new ImageIcon(ClassLoader.getSystemResource("Criminall/icons/print.jpg"));
        id9.setIcon(img);

        id8 = new JLabel("Criminal Details");
        id8.setBounds(50,10,250,30);
        f.add(id8);
        id8.setFont(new Font("serif",Font.BOLD,25));
        id9.add(id8);
        f.add(id9);

        id = new JLabel("Criminal Id:");
        id.setBounds(50,50,120,30);
        id.setFont(new Font("serif",Font.BOLD,20));
        id.setForeground(Color.white);
        id9.add(id);

        aid = new JLabel(Crm_Id);
        aid.setBounds(200,50,200,30);
        aid.setFont(new Font("serif",Font.BOLD,20));
        aid.setForeground(Color.white);
        id9.add(aid);

        id1 = new JLabel("Name:");
        id1.setBounds(50,100,100,30);
        id1.setFont(new Font("serif",Font.BOLD,20));
        id1.setForeground(Color.white);
        id9.add(id1);

        aid1 = new JLabel(name);
        aid1.setBounds(200,100,300,30);
        aid1.setFont(new Font("serif",Font.BOLD,20));
        aid1.setForeground(Color.white);
        id9.add(aid1);

  
        id2 = new JLabel("Height:"); 
        id2.setBounds(50,150,200,30);
        id2.setFont(new Font("serif",Font.BOLD,20));
        id2.setForeground(Color.white);
        id9.add(id2);

        aid2 = new JLabel(height);
        aid2.setBounds(200,150,300,30);
        aid2.setFont(new Font("serif",Font.BOLD,20));
        aid2.setForeground(Color.white);
        id9.add(aid2);

        id3= new JLabel("Weight:");
        id3.setBounds(50,200,100,30);
        id3.setFont(new Font("serif",Font.BOLD,20));
        id3.setForeground(Color.white);
        id9.add(id3);

        aid3= new JLabel(weight);
        aid3.setBounds(200,200,300,30);
        aid3.setFont(new Font("serif",Font.BOLD,20));
        aid3.setForeground(Color.white);
        id9.add(aid3);


        id4= new JLabel("City:");  
        id4.setBounds(50,250,100,30);
        id4.setFont(new Font("serif",Font.BOLD,20));
        id4.setForeground(Color.white);
        id9.add(id4);

        aid4= new JLabel(city);
        aid4.setBounds(200,250,300,30); 
        aid4.setFont(new Font("serif",Font.BOLD,20));
        aid4.setForeground(Color.white);
        id9.add(aid4);

        
        id5= new JLabel("Country:");
        id5.setBounds(50,300,100,30);
        id5.setFont(new Font("serif",Font.BOLD,20));
        id5.setForeground(Color.white);
        id9.add(id5);

        aid5= new JLabel(country);
        aid5.setBounds(200,300,300,30);
        aid5.setFont(new Font("serif",Font.BOLD,20));
        aid5.setForeground(Color.white);
        id9.add(aid5);

        
        id6= new JLabel("Gender:");
        id6.setBounds(50,350,100,30);
        id6.setFont(new Font("serif",Font.BOLD,20));
        id6.setForeground(Color.white);
        id9.add(id6);

        aid6= new JLabel(gender);
        aid6.setBounds(200,350,300,30); 
        aid6.setFont(new Font("serif",Font.BOLD,20));
        aid6.setForeground(Color.white);
        id9.add(aid6);


        id7= new JLabel("Birth Date:");
        id7.setBounds(50,400,100,30);
        id7.setFont(new Font("serif",Font.BOLD,20));
        id7.setForeground(Color.white);
        id9.add(id7);

        aid7= new JLabel(bdate);
        aid7.setBounds(200,400,300,30);
        aid7.setFont(new Font("serif",Font.BOLD,20));
        aid7.setForeground(Color.white);
        id9.add(aid7);
        
        id18= new JLabel("Details:");
        id18.setBounds(50,460,100,30);
        id18.setFont(new Font("serif",Font.BOLD,20));
        id18.setForeground(Color.white);
        id9.add(id18);

        aid9= new JLabel(details);
        aid9.setBounds(200,460,600,30);
        aid9.setFont(new Font("serif",Font.BOLD,20));
        aid9.setForeground(Color.white);
        id9.add(aid9);

        
        b1=new JButton("Print");
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.WHITE);
        b1.setBounds(160,550,100,30);
        b1.addActionListener(this);
        id9.add(b1);

        b2=new JButton("cancel");
        b2.setBackground(Color.BLACK);
        b2.setForeground(Color.WHITE);
        b2.setBounds(310,550,100,30);
        b2.addActionListener(this);
        id9.add(b2);


    }

    public void actionPerformed(ActionEvent ae){

        if(ae.getSource()==b1){
            JOptionPane.showMessageDialog(null,"printed successfully");
            f.setVisible(false);
            details d=new details();
        }
        if(ae.getSource()==b2){
            f.setVisible(false);
            new View_criminal();
        }
    }
    public static void main(String[] args){
        new Print_Data("Print Data");
    }

}